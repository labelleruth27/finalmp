package com.example.mapsproject;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class CameraFragment extends Fragment {

    private static final int REQUEST_CODE = 99;

    private Button btnSnap, btnRotate, btnGrayscale, btnWatermark;
    private ImageView imageView;

    private Bitmap originalBitmap, editedBitmap;
    private float currentRotationAngle = 0; // Sudut rotasi awal

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_camera, container, false);

        btnSnap = view.findViewById(R.id.btncamera);
        btnRotate = view.findViewById(R.id.btnrotate);
        btnGrayscale = view.findViewById(R.id.btngray);
        btnWatermark = view.findViewById(R.id.btnwatermark);
        imageView = view.findViewById(R.id.imageview1);

        btnSnap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, REQUEST_CODE);
            }
        });

        btnRotate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (originalBitmap != null) {
                    // Tingkatkan sudut rotasi
                    currentRotationAngle += 30; // Tambah 30 derajat setiap klik
                    if (currentRotationAngle >= 360) {
                        currentRotationAngle = 0; // Reset ke 0 setelah 360 derajat
                    }

                    // Rotasi gambar
                    editedBitmap = rotateImage(originalBitmap, currentRotationAngle);
                    imageView.setImageBitmap(editedBitmap);

                    // Tampilkan Toast untuk sudut rotasi
                    Toast.makeText(getActivity(), "Rotated to " + currentRotationAngle + "°", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getActivity(), "Capture an image first!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnGrayscale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (originalBitmap != null) {
                    editedBitmap = convertToGrayscale(originalBitmap);
                    imageView.setImageBitmap(editedBitmap);
                } else {
                    Toast.makeText(getActivity(), "Capture an image first!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnWatermark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (originalBitmap != null) {
                    editedBitmap = addWatermark(originalBitmap, "Group 3");
                    imageView.setImageBitmap(editedBitmap);
                } else {
                    Toast.makeText(getActivity(), "Capture an image first!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE && resultCode == getActivity().RESULT_OK) {
            if (data != null && data.getExtras() != null) {
                originalBitmap = (Bitmap) data.getExtras().get("data");
                imageView.setImageBitmap(originalBitmap);
                saveImageToGallery(originalBitmap);
                Toast.makeText(getActivity(), "Image captured!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getActivity(), "No image captured", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(getActivity(), "Camera canceled", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveImageToGallery(Bitmap bitmap) {
        String savedImageURL = MediaStore.Images.Media.insertImage(
                getActivity().getContentResolver(),
                bitmap,
                "Captured Image",
                "Image of something"
        );

        if (savedImageURL != null) {
            Toast.makeText(getActivity(), "Image saved to gallery!", Toast.LENGTH_SHORT).show();

            // Notify media scanner about the new image
            Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            mediaScanIntent.setData(Uri.parse(savedImageURL));
            getActivity().sendBroadcast(mediaScanIntent);
        } else {
            Toast.makeText(getActivity(), "Failed to save image", Toast.LENGTH_SHORT).show();
        }
    }

    // Fungsi untuk memutar gambar
    private Bitmap rotateImage(Bitmap source, float angle) {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
    }

    // Fungsi untuk mengubah gambar menjadi grayscale
    private Bitmap convertToGrayscale(Bitmap source) {
        Bitmap grayscaleBitmap = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(grayscaleBitmap);
        Paint paint = new Paint();
        paint.setColorFilter(new android.graphics.ColorMatrixColorFilter(new float[]{
                0.299f, 0.587f, 0.114f, 0, 0,
                0.299f, 0.587f, 0.114f, 0, 0,
                0.299f, 0.587f, 0.114f, 0, 0,
                0, 0, 0, 1, 0
        }));
        canvas.drawBitmap(source, 0, 0, paint);
        return grayscaleBitmap;
    }

    // Fungsi untuk menambahkan watermark
    private Bitmap addWatermark(Bitmap source, String watermarkText) {
        Bitmap watermarkBitmap = source.copy(Bitmap.Config.ARGB_8888, true);
        Canvas canvas = new Canvas(watermarkBitmap);
        Paint paint = new Paint();
        paint.setColor(Color.RED);
        paint.setTextSize(40);
        paint.setAntiAlias(true);
        canvas.drawText(watermarkText, 20, source.getHeight() - 40, paint);
        return watermarkBitmap;
    }
}
